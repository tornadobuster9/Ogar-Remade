// Imports
var GameMode = require('../gamemodes');
var Entity = require('../entity');
var clc = require('cli-color');

function Commands() {
	this.list = {};
	// Empty
}

module.exports = Commands;

// Utils
var fillChar = function(data, char, fieldLength, rTL) {
	var result = data.toString();
	if (rTL === true) {
		for (var i = result.length; i < fieldLength; i++)
			result = char.concat(result);
	} else {
		for (var i = result.length; i < fieldLength; i++)
			result = result.concat(char);
	}
	return result;
};

// Commands
Commands.list = {
	help : function(gameServer, split) {
		console.log("[Console] ================================================================================");
		console.log("[Console] Help Section:");
		console.log("[Console] ================================================================================");
		console.log("[Console] addbot [number]                      | adds a bot to the server");
		console.log("[Console] kickbot [number]                     | removes an amount of bots");
		console.log("[Console] board [string] [string] ...          | sets scoreboard text");
		console.log("[Console] boardreset                           | resets scoreboard text");
		console.log("[Console] change [setting] [value]             | changes specified settings");
		console.log("[Console] clear                                | clears console output");
		console.log("[Console] color [PlayerID] [R] [G] [B]         | sets cell(s) color by client ID");
		console.log("[Console] exit                                 | stops the server");
		console.log("[Console] food [X pos] [Y pos] [mass]          | spawns food at specified Location");
		console.log("[Console] gamemode [id]                        | changes server gamemode");
		console.log("[Console] getip                                | returns address of the server");
		console.log("[Console] kick [PlayerID]                      | kicks player or bot by client ID");
		console.log("[Console] kickall                              | kicks all players and bots");
		console.log("[Console] kill [PlayerID]                      | kills cell(s) by client ID");
		console.log("[Console] killall                              | kills all cells, both players or bots");
		console.log("[Console] mass [PlayerID] [mass]               | sets cell(s) mass by client ID");
		console.log("[Console] merge [PlayerID]                     | merges all client's cells once");
		console.log("[Console] name [PlayerID] [name]               | changes cell(s) name by client ID");
		console.log("[Console] playerlist                           | gets a list of players and bots");
		console.log("[Console] pause                                | pauses game, freezing all cells");
		console.log("[Console] reload                               | reloads the config (not recommended)");
		console.log("[Console] resetantiteam [PlayerID]             | resets anti-team effect on client");
		console.log("[Console] status                               | gets the server status");
		console.log("[Console] tp [PlayerID] [X pos] [Y pos]        | teleports player to specified location");
		console.log("[Console] virus [X pos] [Y pos] [mass]         | spawns virus at a specified Location");
		console.log("[Console] ================================================================================");
		console.log("[Console] pl                                   | alias for playerlist");
		console.log("[Console] st                                   | alias for status");
		console.log("[Console] ================================================================================");
	},
	addbot : function(gameServer, split) {
		var add = parseInt(split[1]);
		if (isNaN(add)) {
			add = 1;
			// Adds 1 bot if user doesnt specify a number
		}

		for (var i = 0; i < add; i++) {
			setTimeout(gameServer.bots.addBot.bind(gameServer.bots), i);
		}
		console.log("[Console] Added " + add + " player bot(s)");
	},
	kickbot : function(gameServer, split) {
		var toRemove = parseInt(split[1]);
		if (isNaN(toRemove)) {
			toRemove = -1;
			// Kick all bots if user doesnt specify a number
		}

		var removed = 0;
		var i = 0;
		while (i < gameServer.clients.length && removed != toRemove) {
			if (typeof gameServer.clients[i].remoteAddress == 'undefined') {// if client i is a bot kick him
				var client = gameServer.clients[i].playerTracker;
				var len = client.cells.length;
				for (var j = 0; j < len; j++) {
					gameServer.removeNode(client.cells[0]);
				}
				client.socket.close();
				removed++;
			} else
				i++;
		}
		if (toRemove == -1) {
			console.log("[Console] Kicked all bots (" + removed + ")");
		} else if (toRemove == removed) {
			console.log("[Console] Kicked " + toRemove + " bots");
		} else {
			console.log(clc.yellowBright("[Console] Only " + removed + " bots could be kicked"));
		}
	},
	board : function(gameServer, split) {
		var newLB = [];
		for (var i = 1; i < split.length; i++) {
			if (split[i]) {
				newLB[i - 1] = split[i];
			} else {
				newLB[i - 1] = " ";
			}
		}

		// Clears the update leaderboard function and replaces it with our own
		gameServer.gameMode.packetLB = 48;
		gameServer.gameMode.specByLeaderboard = false;
		gameServer.gameMode.updateLB = function(gameServer) {
			gameServer.leaderboard = newLB;
		};
		console.log("[Console] Successfully changed leaderboard values");
	},
	boardreset : function(gameServer) {
		// Gets the current gamemode
		var gm = GameMode.get(gameServer.gameMode.ID);

		// Replace functions
		gameServer.gameMode.packetLB = gm.packetLB;
		gameServer.gameMode.updateLB = gm.updateLB;
		console.log("[Console] Successfully reset leaderboard");
	},
	change : function(gameServer, split) {
		var key = split[1];
		var value = split[2];

		// Check if int/float
		if (value.indexOf('.') != -1) {
			value = parseFloat(value);
		} else {
			value = parseInt(value);
		}

		if ( typeof gameServer.config[key] != 'undefined') {
			gameServer.config[key] = value;
			console.log("[Console] Set " + key + " to " + value);
		} else {
			console.log(clc.redBright("[Console] ERROR: Failed to parse command: Invalid config value"));
		}
	},
	clear : function(gameServer, split) {
		process.stdout.write('\033c');
	},
	color : function(gameServer, split) {
		// Validation checks
		var id = parseInt(split[1]);
		if (isNaN(id)) {
			console.log(clc.redBright("[Console] ERROR: Failed to parse command: Invalid PlayerID"));
			return;
		}

		var color = {
			r : 0,
			g : 0,
			b : 0
		};
		color.r = Math.max(Math.min(parseInt(split[2]), 255), 0);
		color.g = Math.max(Math.min(parseInt(split[3]), 255), 0);
		color.b = Math.max(Math.min(parseInt(split[4]), 255), 0);

		// Sets color to the specified amount
		for (var i in gameServer.clients) {
			if (gameServer.clients[i].playerTracker.pID == id) {
				var client = gameServer.clients[i].playerTracker;
				client.setColor(color);
				// Set color
				for (var j in client.cells) {
					client.cells[j].setColor(color);
				}
				break;
			}
		}
	},
	exit : function(gameServer, split) {
		console.log(clc.yellowBright("[Console] WARNING: All server connections are now stopping. Preparing to close server..."));
		console.log("[Console] Closing webSocket...");
		gameServer.socketServer.close();
		console.log("[Console] Done. Will now stop");
		process.exit(1);
	},
	food : function(gameServer, split) {
		var pos = {
			x : parseInt(split[1]),
			y : parseInt(split[2])
		};
		var mass = parseInt(split[3]);

		// Make sure the input values are numbers
		if (isNaN(pos.x) || isNaN(pos.y)) {
			console.log(clc.redBright("[Console] ERROR: Failed to parse command: Invalid coordinates"));
			return;
		}

		if (isNaN(mass)) {
			mass = gameServer.config.foodStartMass;
		}

		// Spawn
		var f = new Entity.Food(gameServer.getNextNodeId(), null, pos, mass, gameServer);
		f.setColor(gameServer.getRandomColor());
		gameServer.addNode(f);
		gameServer.currentFood++;
		console.log("[Console] Spawned 1 food cell at (" + pos.x + " , " + pos.y + ")");
	},
	gamemode : function(gameServer, split) {
		try {
			var n = parseInt(split[1]);
			var gm = GameMode.get(n);
			// If there is an invalid gamemode, the function will exit
			gameServer.gameMode.onChange(gameServer);
			// Reverts the changes of the old gamemode
			gameServer.gameMode = gm;
			// Apply new gamemode
			gameServer.gameMode.onServerInit(gameServer);
			// Resets the server
			console.log("[Console] Changed game mode to " + gameServer.gameMode.name);
		} catch (e) {
			console.log(clc.redBright("[Console] ERROR: Failed to parse command: Invalid game mode selected"));
		}
	},
	getip : function(gameServer, split) {
		console.log("[Console] Connect by typing 'https://www.agar.io/?ip=localhost:" + gameServer.config.serverPort + "' into the address bar");
	},
	kick : function(gameServer, split) {
		var id = parseInt(split[1]);
		if (isNaN(id)) {
			console.log(clc.redBright("[Console] ERROR: Failed to parse command: Invalid PlayerID"));
			return;
		}

		for (var i in gameServer.clients) {
			if (gameServer.clients[i].playerTracker.pID == id) {
				var client = gameServer.clients[i].playerTracker;
				var len = client.cells.length;
				for (var j = 0; j < len; j++) {
					gameServer.removeNode(client.cells[0]);
				}
				client.socket.close();
				console.log("[Console] Kicked " + client.name);
				break;
			}
		}
	},
	kickall : function(gameServer, split) {
		for (var i in gameServer.clients) {
			var client = gameServer.clients[i].playerTracker;
			var len = client.cells.length;
			for (var j = 0; j < len; j++) {
				gameServer.removeNode(client.cells[0]);
			}
			client.socket.close();
			console.log("[Console] Kicked " + client.name);
		}
	},
	kill : function(gameServer, split) {
		var id = parseInt(split[1]);
		if (isNaN(id)) {
			console.log(clc.redBright("[Console] ERROR: Failed to parse command: Invalid PlayerID"));
			return;
		}

		var count = 0;
		for (var i in gameServer.clients) {
			if (gameServer.clients[i].playerTracker.pID == id) {
				var client = gameServer.clients[i].playerTracker;
				var len = client.cells.length;
				for (var j = 0; j < len; j++) {
					gameServer.removeNode(client.cells[0]);
					count++;
				}

				console.log("[Console] Removed " + count + " cells");
				break;
			}
		}
	},
	killall : function(gameServer, split) {
		var count = 0;
		var len = gameServer.nodesPlayer.length;
		for (var i = 0; i < len; i++) {
			gameServer.removeNode(gameServer.nodesPlayer[0]);
			count++;
		}
		console.log("[Console] Removed " + count + " cells");
	},
	mass : function(gameServer, split) {
		// Validation checks
		var id = parseInt(split[1]);
		if (isNaN(id)) {
			console.log(clc.redBright("[Console] ERROR: Failed to parse command: Invalid PlayerID"));
			return;
		}

		var amount = Math.max(parseInt(split[2]), 9);
		if (isNaN(amount)) {
			console.log("[Console] ERROR: Failed to parse command: Invalid number");
			return;
		}

		// Sets mass to the specified amount
		for (var i in gameServer.clients) {
			if (gameServer.clients[i].playerTracker.pID == id) {
				var client = gameServer.clients[i].playerTracker;
				for (var j in client.cells) {
					client.cells[j].mass = amount;
				}

				console.log("[Console] Set mass of " + client.name + " to " + amount);
				break;
			}
		}
	},
	merge : function(gameServer, split) {
		// Validation checks
		var id = parseInt(split[1]);
		var set = split[2];
		if (isNaN(id)) {
			console.log(clc.redBright("[Console] ERROR: Failed to parse command: Invalid PlayerID"));
			return;
		}

		// Find client with same ID as player entered
		var client;
		for (var i = 0; i < gameServer.clients.length; i++) {
			if (id == gameServer.clients[i].playerTracker.pID) {
				client = gameServer.clients[i].playerTracker;
				break;
			}
		}

		if (!client) {
			console.log(clc.redBright("[Console] ERROR: Failed to run command: Client is nonexistent"));
			return;
		}

		if (client.cells.length == 1) {
			console.log(clc.yellowBright("[Console] WARNING: Failed to run command: Client cell length is already equal to 1"));
			return;
		}

		// Set client's merge override
		var state;
		if (set == "true") {
			client.mergeOverride = true;
			client.mergeOverrideDuration = 100;
			state = true;
		} else if (set == "false") {
			client.mergeOverride = false;
			client.mergeOverrideDuration = 0;
			state = false;
		} else {
			if (client.mergeOverride) {
				client.mergeOverride = false;
				client.mergeOverrideDuration = 0;
			} else {
				client.mergeOverride = true;
				client.mergeOverrideDuration = 100;
			}

			state = client.mergeOverride;
		}

		// Log
		if (state)
			console.log("[Console] Player " + id + " is now force merging");
		else
			console.log("[Console] Player " + id + " isn't force merging anymore");
	},
	name : function(gameServer, split) {
		// Validation checks
		var id = parseInt(split[1]);
		if (isNaN(id)) {
			console.log(clc.redBright("[Console] ERROR: Failed to parse command: Invalid PlayerID"));
			return;
		}

		var name = split.slice(2, split.length).join(' ');
		if ( typeof name == 'undefined') {
			console.log(clc.redBright("[Console] ERROR: Failed to parse command: Invalid name"));
			return;
		}

		// Change name
		for (var i = 0; i < gameServer.clients.length; i++) {
			var client = gameServer.clients[i].playerTracker;

			if (client.pID == id) {
				console.log("[Console] Changed " + client.name + " to " + name);
				client.name = name;
				return;
			}
		}

		// Error
		console.log(clc.redBright("[Console] ERROR: Failed to parse command: Invalid PlayerID"));
	},
	playerlist : function(gameServer, split) {
		console.log("[Console] Showing " + gameServer.clients.length + " players: ");
		console.log(" ID         | IP              | " + fillChar('NICK', ' ', gameServer.config.playerMaxNickLength) + " | CELLS | SCORE  | POSITION    ");
		// Fill space
		console.log(fillChar('', '-', ' ID         | IP              |  | CELLS | SCORE  | POSITION    '.length + gameServer.config.playerMaxNickLength));
		for (var i = 0; i < gameServer.clients.length; i++) {
			var client = gameServer.clients[i].playerTracker;

			// ID with 3 digits length
			var id = fillChar((client.pID), ' ', 10, true);

			// Get ip (15 digits length)
			var ip = "BOT";
			if ( typeof gameServer.clients[i].remoteAddress != 'undefined') {
				ip = gameServer.clients[i].remoteAddress;
			}
			ip = fillChar(ip, ' ', 15);

			// Get name and data
			var nick = '',
			    cells = '',
			    score = '',
			    position = '',
			    data = '';
			if (client.spectate) {
				try {
					nick = gameServer.largestClient.name;
				} catch (e) {
					// Specating in free-roam mode
					nick = "in free-roam";
				}
				nick = (nick == "") ? "An unnamed cell" : nick;
				data = fillChar("SPECTATING: " + nick, '-', ' | CELLS | SCORE  | POSITION    '.length + gameServer.config.playerMaxNickLength, true);
				console.log(" " + id + " | " + ip + " | " + data);
			} else if (client.cells.length > 0) {
				nick = fillChar((client.name == "") ? "An unnamed cell" : client.name, ' ', gameServer.config.playerMaxNickLength);
				cells = fillChar(client.cells.length, ' ', 5, true);
				score = fillChar(client.getScore(true), ' ', 6, true);
				position = fillChar(client.centerPos.x >> 0, ' ', 5, true) + ', ' + fillChar(client.centerPos.y >> 0, ' ', 5, true);
				console.log(" " + id + " | " + ip + " | " + nick + " | " + cells + " | " + score + " | " + position);
			} else {
				// No cells = dead player or in-menu
				data = fillChar('DEAD OR NOT PLAYING', '-', ' | CELLS | SCORE  | POSITION    '.length + gameServer.config.playerMaxNickLength, true);
				console.log(" " + id + " | " + ip + " | " + data);
			}
		}
	},
	pause : function(gameServer, split) {
		gameServer.run = !gameServer.run;
		// Switches the pause state
		var s = gameServer.run ? "Unpaused" : "Paused";
		if (s == "Unpaused") {
			s = "Resumed";
		}
		console.log("[Console] " + s + " the game");
	},
	reload : function(gameServer) {
		gameServer.loadConfig();
		console.log(clc.yellowBright("[Console] WARNING: Reloading the config can have unintended side-effects"));
		console.log("[Console] Reloaded the config file successfully");
	},
	resetantiteam : function(gameServer, split) {
		// Validation checks
		var id = parseInt(split[1]);
		if (isNaN(id)) {
			console.log(clc.redBright("[Console] ERROR: Failed to parse command: Invalid PlayerID"));
			return;
		}

		for (var i in gameServer.clients) {
			var client = gameServer.clients[i];
			if (!client)
				continue;
			// Nonexistent

			if (client.playerTracker.pID == id) {
				// Found client
				client.playerTracker.massDecayMult = 1;
				client.playerTracker.Wmult = 0;
				client.playerTracker.virusMult = 0;
				client.playerTracker.splittingMult = 0;
				console.log("[Console] Successfully reset client's anti-team effect");
				return;
			}
		}
	},
	status : function(gameServer, split) {
		// Get amount of humans/bots
		var humans = 0,
		    bots = 0;
		for (var i = 0; i < gameServer.clients.length; i++) {
			if ('_socket' in gameServer.clients[i]) {
				humans++;
			} else {
				bots++;
			}
		}
		console.log("[Console] Server status:");
		console.log("[Console]");
		console.log("[Console] Connected players: " + gameServer.clients.length + "/" + gameServer.config.serverMaxConnections);
		console.log("[Console] Players: " + humans);
		console.log("[Console] Bots: " + bots);
		console.log("[Console] Server has been running for " + Math.floor(process.uptime() / 60) + " minutes");
		console.log("[Console] Current memory usage: " + Math.round(process.memoryUsage().heapUsed / 1048576 * 10) / 10 + "/" + Math.round(process.memoryUsage().heapTotal / 1048576 * 10) / 10 + " mb");
		console.log("[Console] Current game mode: " + gameServer.gameMode.name);
	},
	tp : function(gameServer, split) {
		var id = parseInt(split[1]);
		if (isNaN(id)) {
			console.log(clc.redBright("[Console] ERROR: Failed to parse command: Invalid PlayerID"));
			return;
		}

		// Make sure the input values are numbers
		var pos = {
			x : parseInt(split[2]),
			y : parseInt(split[3])
		};
		if (isNaN(pos.x) || isNaN(pos.y)) {
			console.log(clc.redBright("[Console] ERROR: Failed to parse command: Invalid coordinates"));
			return;
		}

		// Spawn
		for (var i in gameServer.clients) {
			if (gameServer.clients[i].playerTracker.pID == id) {
				var client = gameServer.clients[i].playerTracker;
				for (var j in client.cells) {
					client.cells[j].position.x = pos.x;
					client.cells[j].position.y = pos.y;
				}

				console.log("[Console] Teleported " + client.name + " to (" + pos.x + " , " + pos.y + ")");
				break;
			}
		}
	},
	virus : function(gameServer, split) {
		var pos = {
			x : parseInt(split[1]),
			y : parseInt(split[2])
		};
		var mass = parseInt(split[3]);

		// Make sure the input values are numbers
		if (isNaN(pos.x) || isNaN(pos.y)) {
			console.log(clc.redBright("[Console] ERROR: Failed to parse command: Invalid coordinates"));
			return;
		}
		if (isNaN(mass)) {
			mass = gameServer.config.virusStartMass;
		}

		// Spawn
		var v = new Entity.Virus(gameServer.getNextNodeId(), null, pos, mass);
		gameServer.addNode(v);
		console.log("[Console] Spawned 1 virus at (" + pos.x + " , " + pos.y + ")");
	},
	// Aliases
	st : function(gameServer, split) {
		Commands.list.status(gameServer, split);
	},
	pl : function(gameServer, split) {
		Commands.list.playerlist(gameServer, split);
	}
};
