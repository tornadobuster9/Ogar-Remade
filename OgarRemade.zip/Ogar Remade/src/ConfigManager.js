// Imports
var YAML = require('js-yaml');
var fs = require('fs');
var clc = require('cli-color');

// Check if the folder exists
if (!fs.existsSync('./server-config')) {
	fs.mkdir('./server-config');
}

var serverConfig = {
	configUnsafeValues: false
}

var serverConfigFile = `
# This is the Ogar-Remade server config file
# This only affects the console, how it behaves,
# etc. It does NOT handle gameplay tactics. For
# this, go to the gameserver.ini file


# Allow unsafe values in the config?
# An 'unsafe value' is when a config option has a
# really high value (like 9999999999)
# If set to false, this will not allow unsafe values
# If set to true, this will allow unsafe values
# Defaults to false
configUnsafeValues: false
`;

// Load config
try {
	var serverConfiguration = YAML.safeLoad(fs.readFileSync("./server-config/config.yml", 'utf-8'));

	for (var obj in serverConfiguration) {
		serverConfig[obj] = serverConfiguration[obj];
	}
} catch (err) {
	// No config found, or the config contains invalid values
	fs.writeFileSync('./server-config/config.yml', serverConfigFile);
}

module.exports = {
	getValue: function (str) {
		switch (value = str) {
		case "configUnsafeValues":
			return serverConfig.configUnsafeValues;
			break;
		default:
			return null;
			break;
		}
	}
}