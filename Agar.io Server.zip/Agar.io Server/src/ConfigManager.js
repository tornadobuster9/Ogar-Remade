// Imports
var YAML = require('js-yaml');
var fs = require('fs');
var clc = require('cli-color');

// Check if the folder exists
if (!fs.existsSync('./server-config')) {
	fs.mkdir('./server-config');
	fs.chmod('./server-config', '777');
}

// Values
var serverConfig = {
	"config-unsafe-values": false,
	"show-motd": true,
	"wait-on-start": true
}

var messageConfig = {
	"no-command": "Unknown command. Type 'help' for help",
	"start-message": "Loading libraries... please wait...",
	"internal-error": "An unknown error occured. Refer to the log for more info",
	"unsafe-value": "An unsafe value was found in the config! Stopping..."
}


// The server config created
var serverConfigFile = `# Allow unsafe values
config-unsafe-values: false

# Should the server wait a bit before starting?
# This is recommended so that libraries can load
# and will make your server a bit faster
wait-on-start: true

# Display message of the day?
# This is just a multi-line welcome message that
# you get on startup
show-motd: true

# WARNING: If Ogar-Remade is unable to parse this
# file, IT WILL BE RESET
# This goes for all the other files as well`;

// The message config created
var messageConfigFile = `# This configures the messages output in the console
# More will be added over time
# One more thing, if you want to literally put double quotes inside
# an entry, put a backslash before it (\\")

# The message you get when you try to type in an invalid command
no-command: "Unknown command. Type 'help' for help"

# The message you get on startup. Set to '' to disable
start-message: "Loading libraries... please wait..."

# The message you get when any internal error occurs
internal-error: "An unknown error occured. Refer to the log for more info"

# The message you get when an unsafe value is detected in the config
unsafe-value: "An unsafe value was found in the config! Stopping..."`;

// Motd file
var motdFile = `Welcome to Ogar Remade!
This is a little message that
you can change and/or disable
in the config. You can also
have multiple lines here!
Colored text will be coming soon!`;

// Load server config
try {
	var serverConfiguration = YAML.safeLoad(fs.readFileSync("./server-config/config.yml", 'utf-8'));

	for (var obj in serverConfiguration) {
		serverConfig[obj] = serverConfiguration[obj];
	}
} catch (err) {
	// No config found, or the config contains invalid values
	fs.writeFileSync('./server-config/config.yml', serverConfigFile);
	fs.chmod('./server-config/config.yml', '777');
}

// Load messages config
try {
	var messageConfiguration = YAML.safeLoad(fs.readFileSync("./server-config/messages.yml", 'utf-8'));

	for (var obj in messageConfiguration) {
		messageConfig[obj] = messageConfiguration[obj];
	}
} catch (err) {
	// No config found, or the config contains invalid values
	fs.writeFileSync("./server-config/messages.yml", messageConfigFile);
	fs.chmod("./server-config/messages.yml", '777');
}

// Load MOTD
var motdLoaded = [];
try {
	var motdConfiguration = fs.readFileSync("./server-config/motd.txt", 'utf-8');
	var splitMotdConfiguration = motdConfiguration.split("\n");

	for (var obj in splitMotdConfiguration) {
		motdLoaded.push(splitMotdConfiguration[obj]);
	}
} catch (err) {
	// No file
	fs.writeFileSync("./server-config/motd.txt", motdFile);
	fs.chmod("./server-config/motd.txt", '777');
}

// Allow other modules to use loaded config variables
module.exports = {
	loadedServerConfig: serverConfig,
	loadedMessageConfig: messageConfig,
	loadedMotdConfig: motdLoaded
}