// Imports
var Commands = require('./modules/CommandList');
var GameServer = require('./GameServer');
var clc = require('cli-color');
var sleep = require('system-sleep');
var ConfigManager = require('./ConfigManager');

// MOTD
if (ConfigManager.loadedMotdConfig.length > 0 && ConfigManager.loadedServerConfig["show-motd"]) {
    console.log("==============================================================");

    for (var x = 0; x < ConfigManager.loadedMotdConfig.length; x++) {
        console.log(ConfigManager.loadedMotdConfig[x]);
    }

    console.log("==============================================================");
}

// Start message
if (ConfigManager.loadedMessageConfig["start-message"].length > 0) {console.log("[Console] " + ConfigManager.loadedMessageConfig["start-message"]);}

// Let the server load
if (ConfigManager.loadedServerConfig["wait-on-start"]) {sleep(3000);}

// Handle arguments
process.argv.forEach(function(val) {
    if (val == "--help") {
       	console.log("[Console] Because this is a modified version of Ogar, we are not able to provide you with actuall help support");
        console.log("[Console] Instead, visit the GitHub project here: https://github.com/tornadobuster9/Ogar-Remade");
        console.log("[Console] Please provide detailed information on the error or we most likely won't help you");
        process.exit(1);
    }
});

// Start the server
var gameServer = new GameServer();
gameServer.start();

// Add command handler
gameServer.commands = Commands.list;

// Console
var readline = require('readline');
var in_ = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

setTimeout(prompt, 100);

function prompt() {
    in_.question(">>> ", function(str) {
        parseCommands(str);
        return prompt(); // Too lazy to learn async
    });
}

function parseCommands(str) {
    // Wait a split second so the command can process
    sleep(20);

    // Log the string
    gameServer.log.onCommand(str);

    // Don't process ENTER
    if (str === "")
        return;

    // Splits the string
    var split = str.split(" ");

    // Process the first string value
    var first = split[0].toLowerCase();

    // Get command function
    var execute = gameServer.commands[first];
    
    if (typeof execute != 'undefined') {
        execute(gameServer, split);
    } else {
        console.log(clc.redBright("[Console] ERROR: " + ConfigManager.loadedMessageConfig["no-command"]));
    }
}
